package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_stats")
data class GameStatsEntity(
    @PrimaryKey val id: Int = 1,
    val highScore: Int = 0,
    val longestStreak: Int = 0,
    val bestAccuracy: Float = 0f,
    val fastestReactionMs: Long = 0L,
    val highestMultiplier: Int = 1,
    val perfectMilestones: Int = 0,
    val totalGamesPlayed: Int = 0,
    val totalCorrectAnswers: Int = 0,
    val bestDailyChallengeScore: Int = 0
)

@Entity(tableName = "daily_streak")
data class DailyStreakEntity(
    @PrimaryKey val id: Int = 1,
    val currentStreak: Int = 0,
    val lastPlayedDate: String = "",
    val bestDailyStreak: Int = 0
)

@Entity(tableName = "daily_challenges")
data class DailyChallengeEntity(
    @PrimaryKey val date: String, // "YYYY-MM-DD"
    val score: Int = 0,
    val accuracy: Float = 0f,
    val fastestReactionMs: Long = 0L,
    val completed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_history")
data class GameHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val mode: String, // "NORMAL" or "DAILY_CHALLENGE"
    val score: Int,
    val streak: Int,
    val accuracy: Float,
    val avgReactionMs: Long,
    val fastestReactionMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)
