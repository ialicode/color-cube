package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.data.db.ColorCubeDatabase
import com.example.data.db.DailyChallengeEntity
import com.example.data.db.DailyStreakEntity
import com.example.data.db.GameDao
import com.example.data.db.GameHistoryEntity
import com.example.data.db.GameStatsEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("color_cube_prefs", Context.MODE_PRIVATE)

    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()

    var hapticsEnabled: Boolean
        get() = prefs.getBoolean("haptics_enabled", true)
        set(value) = prefs.edit().putBoolean("haptics_enabled", value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean("notifications_enabled", true)
        set(value) = prefs.edit().putBoolean("notifications_enabled", value).apply()

    var isTestAds: Boolean
        get() = prefs.getBoolean("is_test_ads", com.example.ads.AdConfig.IS_TEST_MODE)
        set(value) = prefs.edit().putBoolean("is_test_ads", value).apply()

    var gamesSinceLastInterstitial: Int
        get() = prefs.getInt("games_since_interstitial", 0)
        set(value) = prefs.edit().putInt("games_since_interstitial", value).apply()
}

class GameRepository(private val gameDao: GameDao) {

    val gameStats: Flow<GameStatsEntity?> = gameDao.getGameStats()
    val dailyStreak: Flow<DailyStreakEntity?> = gameDao.getDailyStreak()
    val recentHistory: Flow<List<GameHistoryEntity>> = gameDao.getRecentHistory()

    fun getDailyChallengeFlow(date: String): Flow<DailyChallengeEntity?> =
        gameDao.getDailyChallenge(date)

    suspend fun recordGameFinished(
        mode: String,
        score: Int,
        streak: Int,
        accuracy: Float,
        avgReactionMs: Long,
        fastestReactionMs: Long,
        multiplierReached: Int,
        perfectMilestonesInRun: Int,
        correctCount: Int
    ): Boolean {
        val todayStr = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)

        // Save history item
        val history = GameHistoryEntity(
            date = todayStr,
            mode = mode,
            score = score,
            streak = streak,
            accuracy = accuracy,
            avgReactionMs = avgReactionMs,
            fastestReactionMs = fastestReactionMs
        )
        gameDao.insertGameHistory(history)

        // Update Daily Streak
        updateDailyStreak(todayStr)

        // Update Aggregate Stats
        val currentStats = gameDao.getGameStatsDirect() ?: GameStatsEntity()
        val isNewHighScore = score > currentStats.highScore
        val newHighScore = maxOf(currentStats.highScore, score)
        val newLongestStreak = maxOf(currentStats.longestStreak, streak)
        val newBestAccuracy = if (accuracy > currentStats.bestAccuracy) accuracy else currentStats.bestAccuracy
        val newFastestReaction = if (currentStats.fastestReactionMs == 0L || (fastestReactionMs in 1 until currentStats.fastestReactionMs)) {
            fastestReactionMs
        } else {
            currentStats.fastestReactionMs
        }
        val newHighestMultiplier = maxOf(currentStats.highestMultiplier, multiplierReached)
        val newPerfectMilestones = currentStats.perfectMilestones + perfectMilestonesInRun
        val newTotalGames = currentStats.totalGamesPlayed + 1
        val newTotalCorrect = currentStats.totalCorrectAnswers + correctCount

        val updatedStats = currentStats.copy(
            highScore = newHighScore,
            longestStreak = newLongestStreak,
            bestAccuracy = newBestAccuracy,
            fastestReactionMs = newFastestReaction,
            highestMultiplier = newHighestMultiplier,
            perfectMilestones = newPerfectMilestones,
            totalGamesPlayed = newTotalGames,
            totalCorrectAnswers = newTotalCorrect
        )
        gameDao.saveGameStats(updatedStats)

        return isNewHighScore
    }

    suspend fun saveDailyChallengeResult(
        date: String,
        score: Int,
        accuracy: Float,
        fastestReactionMs: Long
    ) {
        val challenge = DailyChallengeEntity(
            date = date,
            score = score,
            accuracy = accuracy,
            fastestReactionMs = fastestReactionMs,
            completed = true
        )
        gameDao.saveDailyChallenge(challenge)

        val currentStats = gameDao.getGameStatsDirect() ?: GameStatsEntity()
        if (score > currentStats.bestDailyChallengeScore) {
            gameDao.saveGameStats(currentStats.copy(bestDailyChallengeScore = score))
        }

        updateDailyStreak(date)
    }

    private suspend fun updateDailyStreak(todayStr: String) {
        val current = gameDao.getDailyStreakDirect() ?: DailyStreakEntity()
        val today = LocalDate.parse(todayStr)

        if (current.lastPlayedDate.isEmpty()) {
            val newStreak = 1
            gameDao.saveDailyStreak(
                DailyStreakEntity(
                    currentStreak = newStreak,
                    lastPlayedDate = todayStr,
                    bestDailyStreak = maxOf(current.bestDailyStreak, newStreak)
                )
            )
            return
        }

        val lastPlayed = try {
            LocalDate.parse(current.lastPlayedDate)
        } catch (e: Exception) {
            today
        }

        val daysDiff = ChronoUnit.DAYS.between(lastPlayed, today)

        when {
            daysDiff == 0L -> {
                // Already played today, streak remains the same
            }
            daysDiff == 1L -> {
                // Consecutive day!
                val newStreak = current.currentStreak + 1
                gameDao.saveDailyStreak(
                    current.copy(
                        currentStreak = newStreak,
                        lastPlayedDate = todayStr,
                        bestDailyStreak = maxOf(current.bestDailyStreak, newStreak)
                    )
                )
            }
            else -> {
                // Streak broken, restart at 1
                val newStreak = 1
                gameDao.saveDailyStreak(
                    current.copy(
                        currentStreak = newStreak,
                        lastPlayedDate = todayStr,
                        bestDailyStreak = maxOf(current.bestDailyStreak, newStreak)
                    )
                )
            }
        }
    }

    suspend fun resetAllRecords() {
        gameDao.clearHistory()
        gameDao.clearStats()
    }
}
