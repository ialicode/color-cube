package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {

    @Query("SELECT * FROM game_stats WHERE id = 1")
    fun getGameStats(): Flow<GameStatsEntity?>

    @Query("SELECT * FROM game_stats WHERE id = 1")
    suspend fun getGameStatsDirect(): GameStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGameStats(stats: GameStatsEntity)

    @Query("SELECT * FROM daily_streak WHERE id = 1")
    fun getDailyStreak(): Flow<DailyStreakEntity?>

    @Query("SELECT * FROM daily_streak WHERE id = 1")
    suspend fun getDailyStreakDirect(): DailyStreakEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDailyStreak(streak: DailyStreakEntity)

    @Query("SELECT * FROM daily_challenges WHERE date = :date")
    fun getDailyChallenge(date: String): Flow<DailyChallengeEntity?>

    @Query("SELECT * FROM daily_challenges WHERE date = :date")
    suspend fun getDailyChallengeDirect(date: String): DailyChallengeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDailyChallenge(challenge: DailyChallengeEntity)

    @Query("SELECT * FROM game_history ORDER BY timestamp DESC LIMIT 20")
    fun getRecentHistory(): Flow<List<GameHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGameHistory(history: GameHistoryEntity)

    @Query("DELETE FROM game_history")
    suspend fun clearHistory()

    @Query("DELETE FROM game_stats")
    suspend fun clearStats()
}
