package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        GameStatsEntity::class,
        DailyStreakEntity::class,
        DailyChallengeEntity::class,
        GameHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ColorCubeDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: ColorCubeDatabase? = null

        fun getDatabase(context: Context): ColorCubeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ColorCubeDatabase::class.java,
                    "color_cube_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
