package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRose

enum class GameColor(
    val displayName: String,
    val primaryColor: Color,
    val topColor: Color,
    val sideColor: Color,
    val isLight: Boolean = false
) {
    RED(
        displayName = "RED",
        primaryColor = Color(0xFFF43F5E), // Neon Rose / Red
        topColor = Color(0xFFFB7185),
        sideColor = Color(0xFFE11D48)
    ),
    BLUE(
        displayName = "BLUE",
        primaryColor = Color(0xFF3B82F6), // Vibrant Blue
        topColor = Color(0xFF60A5FA),
        sideColor = Color(0xFF1D4ED8)
    ),
    GREEN(
        displayName = "GREEN",
        primaryColor = Color(0xFF10B981), // Neon Emerald
        topColor = Color(0xFF34D399),
        sideColor = Color(0xFF059669),
        isLight = true
    ),
    YELLOW(
        displayName = "YELLOW",
        primaryColor = Color(0xFFFBBF24), // Vibrant Amber / Yellow
        topColor = Color(0xFFFDE047),
        sideColor = Color(0xFFD97706),
        isLight = true
    ),
    PURPLE(
        displayName = "PURPLE",
        primaryColor = Color(0xFFA855F7), // Neon Purple
        topColor = Color(0xFFC084FC),
        sideColor = Color(0xFF7E22CE)
    ),
    ORANGE(
        displayName = "ORANGE",
        primaryColor = Color(0xFFFB923C), // Vibrant Orange
        topColor = Color(0xFFFDBA74),
        sideColor = Color(0xFFEA580C)
    );

    companion object {
        // The standard 4 core Stroop colors
        val coreFour = listOf(RED, BLUE, GREEN, YELLOW)
        val allColors = entries.toList()
    }
}
