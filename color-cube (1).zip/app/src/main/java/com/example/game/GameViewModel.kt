package com.example.game

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ColorCubeApp
import com.example.data.GameRepository
import com.example.data.SettingsManager
import com.example.data.db.DailyChallengeEntity
import com.example.data.db.DailyStreakEntity
import com.example.data.db.GameHistoryEntity
import com.example.data.db.GameStatsEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as ColorCubeApp
    private val repository: GameRepository = app.repository
    val settingsManager: SettingsManager = app.settingsManager
    private val soundManager = app.soundManager
    private val hapticManager = app.hapticManager
    private val adManager = app.adManager

    val gameStats: StateFlow<GameStatsEntity?> = repository.gameStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val dailyStreak: StateFlow<DailyStreakEntity?> = repository.dailyStreak
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val recentHistory: StateFlow<List<GameHistoryEntity>> = repository.recentHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _todayChallenge = MutableStateFlow<DailyChallengeEntity?>(null)
    val todayChallenge: StateFlow<DailyChallengeEntity?> = _todayChallenge.asStateFlow()

    private val _gameState = MutableStateFlow(GameSessionState())
    val gameState: StateFlow<GameSessionState> = _gameState.asStateFlow()

    private var questionTimerJob: Job? = null
    private var countdownJob: Job? = null

    init {
        refreshDailyChallenge()
    }

    fun refreshDailyChallenge() {
        viewModelScope.launch {
            val todayStr = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
            repository.getDailyChallengeFlow(todayStr).collect { entity ->
                _todayChallenge.value = entity
            }
        }
    }

    fun startNormalGame() {
        adManager.loadInterstitialAd()
        adManager.loadRewardedAd()
        startCountdown(GameMode.NORMAL)
    }

    fun startDailyChallenge() {
        adManager.loadInterstitialAd()
        startCountdown(GameMode.DAILY_CHALLENGE)
    }

    private fun startCountdown(mode: GameMode, isResumingFromRevive: Boolean = false) {
        questionTimerJob?.cancel()
        countdownJob?.cancel()

        if (!isResumingFromRevive) {
            _gameState.update {
                GameSessionState(
                    mode = mode,
                    phase = GamePhase.COUNTDOWN,
                    lives = if (mode == GameMode.NORMAL) 3 else 3,
                    countdownNumber = 3,
                    countdownText = "3"
                )
            }
        } else {
            _gameState.update {
                it.copy(
                    phase = GamePhase.COUNTDOWN,
                    countdownNumber = 3,
                    countdownText = "3"
                )
            }
        }

        countdownJob = viewModelScope.launch {
            soundManager.playCountdownTick()
            hapticManager.vibrateTap()
            delay(700)

            _gameState.update { it.copy(countdownNumber = 2, countdownText = "2") }
            soundManager.playCountdownTick()
            hapticManager.vibrateTap()
            delay(700)

            _gameState.update { it.copy(countdownNumber = 1, countdownText = "1") }
            soundManager.playCountdownTick()
            hapticManager.vibrateTap()
            delay(700)

            _gameState.update { it.copy(countdownNumber = 0, countdownText = "GO!") }
            soundManager.playCountdownGo()
            hapticManager.vibrateSuccess()
            delay(450)

            _gameState.update { it.copy(phase = GamePhase.PLAYING) }
            presentNextQuestion()
        }
    }

    private fun presentNextQuestion() {
        questionTimerJob?.cancel()
        val state = _gameState.value

        if (state.mode == GameMode.DAILY_CHALLENGE && state.dailyProgressCurrent >= state.dailyProgressTotal) {
            finishDailyChallenge()
            return
        }

        val question = generateQuestion(state)
        val startTime = System.currentTimeMillis()

        _gameState.update {
            it.copy(
                currentQuestion = question,
                questionStartTimeMs = startTime,
                lastAnswerWasCorrect = null,
                lastPointsAwarded = 0,
                selectedOption = null,
                isPerfectEventActive = false
            )
        }

        // Start timer countdown for question
        questionTimerJob = viewModelScope.launch {
            delay(question.timeLimitMs)
            // Time out counted as wrong answer
            handleTimeout()
        }
    }

    private fun generateQuestion(state: GameSessionState): ColorQuestion {
        val coreTiles = GameColor.coreFour // RED, BLUE, GREEN, YELLOW

        if (state.mode == GameMode.DAILY_CHALLENGE) {
            val todayStr = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
            val seed = todayStr.hashCode().toLong() + state.dailyProgressCurrent * 7919L
            val rng = Random(seed)

            // Pick actual text color (the target to tap)
            val textColor = coreTiles.random(rng)

            // Pick the written word text (deliberately mismatch ~85% of the time)
            val isMismatch = rng.nextFloat() < 0.85f
            val word = if (isMismatch) {
                (coreTiles - textColor).random(rng)
            } else {
                textColor
            }

            return ColorQuestion(
                word = word,
                textColor = textColor,
                options = coreTiles,
                timeLimitMs = (2500L - (state.dailyProgressCurrent * 55L)).coerceAtLeast(1200L)
            )
        }

        // NORMAL MODE: Progressive speed
        val correct = state.correctCount
        val textColor = coreTiles.random()
        val isMismatch = Random.nextFloat() < 0.85f
        val word = if (isMismatch) {
            (coreTiles - textColor).random()
        } else {
            textColor
        }

        val timeLimit = when {
            correct < 5 -> 2800L
            correct < 12 -> 2300L
            correct < 22 -> 1800L
            correct < 35 -> 1400L
            else -> 1100L
        }

        return ColorQuestion(
            word = word,
            textColor = textColor,
            options = coreTiles,
            timeLimitMs = timeLimit
        )
    }

    fun selectAnswer(selectedColor: GameColor) {
        val state = _gameState.value
        if (state.phase != GamePhase.PLAYING || state.selectedOption != null) return
        val currentQ = state.currentQuestion ?: return

        questionTimerJob?.cancel()
        val reactionTime = (System.currentTimeMillis() - state.questionStartTimeMs).coerceAtLeast(10L)
        val isCorrect = selectedColor == currentQ.targetColor

        if (isCorrect) {
            handleCorrectAnswer(reactionTime, selectedColor, currentQ)
        } else {
            handleWrongAnswer(reactionTime, selectedColor)
        }
    }

    private fun handleTimeout() {
        val state = _gameState.value
        if (state.phase != GamePhase.PLAYING) return
        handleWrongAnswer(state.currentQuestion?.timeLimitMs ?: 2000L, null)
    }

    private fun handleCorrectAnswer(
        reactionTime: Long,
        selectedColor: GameColor,
        question: ColorQuestion
    ) {
        val state = _gameState.value
        val newStreak = state.currentStreak + 1
        val newBestStreak = maxOf(state.bestStreakInRun, newStreak)

        // Multiplier progression: 1X (0-2), 2X (3-5), 3X (6+)
        val oldMultiplier = state.multiplier
        val newMultiplier = when {
            newStreak >= 6 -> 3
            newStreak >= 3 -> 2
            else -> 1
        }

        val multiplierIncreased = newMultiplier > oldMultiplier

        // Scoring system: exactly +1 at 1X, +2 at 2X, +3 at 3X
        val pointsEarned = newMultiplier
        val newScore = state.score + pointsEarned
        val newReactionTimes = state.reactionTimes + reactionTime
        val newTotal = state.totalQuestionsAnswered + 1
        val newCorrect = state.correctCount + 1

        // Check PERFECT! milestone (every 10 consecutive correct: 10, 20, 30...)
        val isPerfect = newStreak > 0 && newStreak % 10 == 0
        val newPerfectMilestones = if (isPerfect) state.perfectMilestonesInRun + 1 else state.perfectMilestonesInRun

        if (isPerfect) {
            soundManager.playPerfect()
            hapticManager.vibratePerfect()
        } else if (multiplierIncreased) {
            soundManager.playMultiplierUp()
            hapticManager.vibrateMultiplier()
        } else {
            soundManager.playCorrect()
            hapticManager.vibrateSuccess()
        }

        _gameState.update {
            it.copy(
                score = newScore,
                currentStreak = newStreak,
                bestStreakInRun = newBestStreak,
                multiplier = newMultiplier,
                lastReactionTimeMs = reactionTime,
                reactionTimes = newReactionTimes,
                totalQuestionsAnswered = newTotal,
                correctCount = newCorrect,
                isPerfectEventActive = isPerfect,
                perfectMilestonesInRun = newPerfectMilestones,
                lastAnswerWasCorrect = true,
                lastPointsAwarded = pointsEarned,
                selectedOption = selectedColor,
                dailyProgressCurrent = if (it.mode == GameMode.DAILY_CHALLENGE) it.dailyProgressCurrent + 1 else 0
            )
        }

        viewModelScope.launch {
            val delayMs = if (isPerfect) 450L else 200L
            delay(delayMs)
            if (_gameState.value.phase == GamePhase.PLAYING) {
                presentNextQuestion()
            }
        }
    }

    private fun handleWrongAnswer(reactionTime: Long, selectedColor: GameColor?) {
        val state = _gameState.value
        val newLives = (state.lives - 1).coerceAtLeast(0)
        val newTotal = state.totalQuestionsAnswered + 1
        val newReactionTimes = if (selectedColor != null) state.reactionTimes + reactionTime else state.reactionTimes

        soundManager.playWrong()
        hapticManager.vibrateError()

        _gameState.update {
            it.copy(
                lives = newLives,
                currentStreak = 0,
                multiplier = 1,
                lastReactionTimeMs = reactionTime,
                reactionTimes = newReactionTimes,
                totalQuestionsAnswered = newTotal,
                lastAnswerWasCorrect = false,
                lastPointsAwarded = 0,
                selectedOption = selectedColor,
                dailyProgressCurrent = if (it.mode == GameMode.DAILY_CHALLENGE) it.dailyProgressCurrent + 1 else 0
            )
        }

        viewModelScope.launch {
            delay(350L)
            if (newLives <= 0) {
                if (state.mode == GameMode.NORMAL && state.isReviveAvailable) {
                    // Out of lives - Offer Save My Run Rewarded Ad
                    _gameState.update { it.copy(phase = GamePhase.REVIVE_PROMPT) }
                } else if (state.mode == GameMode.DAILY_CHALLENGE) {
                    finishDailyChallenge()
                } else {
                    finishNormalGame()
                }
            } else {
                presentNextQuestion()
            }
        }
    }

    fun requestSaveMyRun(activity: Activity) {
        val state = _gameState.value
        if (state.phase != GamePhase.REVIVE_PROMPT || !state.isReviveAvailable) return

        adManager.showRewardedAd(
            activity = activity,
            onRewardEarned = {
                soundManager.playRevive()
                hapticManager.vibrateRevive()
                _gameState.update {
                    it.copy(
                        lives = 1,
                        isReviveAvailable = false,
                        phase = GamePhase.REVIVE_SUCCESS
                    )
                }
            },
            onAdFailedOrClosed = {
                finishNormalGame()
            }
        )
    }

    fun declineRevive() {
        finishNormalGame()
    }

    fun continueFromReviveSuccess() {
        startCountdown(GameMode.NORMAL, isResumingFromRevive = true)
    }

    private fun finishNormalGame() {
        questionTimerJob?.cancel()
        val state = _gameState.value
        soundManager.playGameOver()

        viewModelScope.launch {
            val isNewBest = repository.recordGameFinished(
                mode = "NORMAL",
                score = state.score,
                streak = state.bestStreakInRun,
                accuracy = state.accuracyPercentage,
                avgReactionMs = state.averageReactionTimeMs,
                fastestReactionMs = state.fastestReactionTimeMs,
                multiplierReached = state.multiplier,
                perfectMilestonesInRun = state.perfectMilestonesInRun,
                correctCount = state.correctCount
            )

            _gameState.update {
                it.copy(
                    phase = GamePhase.GAME_OVER,
                    isNewHighScore = isNewBest
                )
            }
        }
    }

    private fun finishDailyChallenge() {
        questionTimerJob?.cancel()
        val state = _gameState.value
        val todayStr = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)

        viewModelScope.launch {
            repository.saveDailyChallengeResult(
                date = todayStr,
                score = state.score,
                accuracy = state.accuracyPercentage,
                fastestReactionMs = state.fastestReactionTimeMs
            )

            _gameState.update {
                it.copy(phase = GamePhase.DAILY_RESULTS)
            }
        }
    }

    fun navigateToHome(activity: Activity? = null) {
        questionTimerJob?.cancel()
        countdownJob?.cancel()

        if (activity != null) {
            adManager.showInterstitialIfReady(activity) {
                _gameState.update { GameSessionState(phase = GamePhase.HOME) }
            }
        } else {
            _gameState.update { GameSessionState(phase = GamePhase.HOME) }
        }
    }

    fun navigateToRecords() {
        _gameState.update { it.copy(phase = GamePhase.RECORDS) }
    }

    fun navigateToSettings() {
        _gameState.update { it.copy(phase = GamePhase.SETTINGS) }
    }

    fun playAgain(activity: Activity) {
        val currentMode = _gameState.value.mode
        adManager.showInterstitialIfReady(activity) {
            if (currentMode == GameMode.DAILY_CHALLENGE) {
                startDailyChallenge()
            } else {
                startNormalGame()
            }
        }
    }

    fun toggleSound(enabled: Boolean) {
        settingsManager.soundEnabled = enabled
    }

    fun toggleHaptics(enabled: Boolean) {
        settingsManager.hapticsEnabled = enabled
    }

    fun toggleNotifications(enabled: Boolean, context: android.content.Context) {
        settingsManager.notificationsEnabled = enabled
        if (enabled) {
            com.example.receiver.StreakReminderReceiver.scheduleStreakReminder(context)
        } else {
            com.example.receiver.StreakReminderReceiver.cancelStreakReminder(context)
        }
    }

    fun toggleTestAds(enabled: Boolean) {
        settingsManager.isTestAds = enabled
    }

    fun resetRecords() {
        viewModelScope.launch {
            repository.resetAllRecords()
        }
    }
}
