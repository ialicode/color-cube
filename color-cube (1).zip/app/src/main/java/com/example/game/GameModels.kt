package com.example.game

enum class GameMode {
    NORMAL,
    DAILY_CHALLENGE
}

enum class GamePhase {
    HOME,
    COUNTDOWN,
    PLAYING,
    REVIVE_PROMPT,
    REVIVE_SUCCESS,
    GAME_OVER,
    DAILY_RESULTS,
    RECORDS,
    SETTINGS
}

/**
 * Stroop-Effect Question:
 * [word] is the text written on screen (e.g. "YELLOW").
 * [textColor] is the actual ink/font color in which the word is displayed (e.g. BLUE).
 * The correct answer is ALWAYS [textColor].
 */
data class ColorQuestion(
    val word: GameColor,
    val textColor: GameColor,
    val options: List<GameColor>,
    val timeLimitMs: Long = 3000L
) {
    // For convenience / backwards compatibility
    val targetColor: GameColor get() = textColor
}

data class GameSessionState(
    val mode: GameMode = GameMode.NORMAL,
    val phase: GamePhase = GamePhase.HOME,
    val score: Int = 0,
    val lives: Int = 3,
    val maxLives: Int = 3,
    val currentStreak: Int = 0,
    val bestStreakInRun: Int = 0,
    val multiplier: Int = 1,
    val currentQuestion: ColorQuestion? = null,
    val questionStartTimeMs: Long = 0L,
    val lastReactionTimeMs: Long = 0L,
    val reactionTimes: List<Long> = emptyList(),
    val totalQuestionsAnswered: Int = 0,
    val correctCount: Int = 0,
    val isReviveAvailable: Boolean = true,
    val isPerfectEventActive: Boolean = false,
    val perfectMilestonesInRun: Int = 0,
    val isNewHighScore: Boolean = false,
    val countdownNumber: Int = 3,
    val countdownText: String = "3",
    val dailyProgressCurrent: Int = 0,
    val dailyProgressTotal: Int = 20,
    val lastAnswerWasCorrect: Boolean? = null,
    val lastPointsAwarded: Int = 0,
    val selectedOption: GameColor? = null
) {
    val accuracyPercentage: Float
        get() = if (totalQuestionsAnswered == 0) 0f else (correctCount.toFloat() / totalQuestionsAnswered.toFloat()) * 100f

    val averageReactionTimeMs: Long
        get() = if (reactionTimes.isEmpty()) 0L else reactionTimes.average().toLong()

    val fastestReactionTimeMs: Long
        get() = reactionTimes.minOrNull() ?: 0L
}
