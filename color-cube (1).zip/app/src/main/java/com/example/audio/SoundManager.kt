package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.data.SettingsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundManager(context: Context, private val settingsManager: SettingsManager) {
    private val scope = CoroutineScope(Dispatchers.Default)

    // Pre-generated audio buffers
    private val sampleRate = 44100
    private val tapBuffer = generateToneBuffer(frequencies = doubleArrayOf(800.0), durationMs = 35, attackMs = 2, decayMs = 30)
    private val correctBuffer = generateChimeBuffer(frequencies = doubleArrayOf(587.33, 880.0), durationMs = 120) // D5 -> A5
    private val wrongBuffer = generateToneBuffer(frequencies = doubleArrayOf(160.0, 150.0), durationMs = 160, attackMs = 5, decayMs = 150)
    private val multiplierBuffer = generateArpeggioBuffer(frequencies = doubleArrayOf(523.25, 659.25, 783.99, 1046.50), noteDurationMs = 50)
    private val perfectBuffer = generateCelebrationBuffer()
    private val gameOverBuffer = generateArpeggioBuffer(frequencies = doubleArrayOf(440.0, 415.30, 392.0, 329.63), noteDurationMs = 90)
    private val countdownTickBuffer = generateToneBuffer(frequencies = doubleArrayOf(440.0), durationMs = 60, attackMs = 2, decayMs = 55)
    private val countdownGoBuffer = generateToneBuffer(frequencies = doubleArrayOf(880.0, 1174.66), durationMs = 180, attackMs = 5, decayMs = 170)
    private val reviveBuffer = generateArpeggioBuffer(frequencies = doubleArrayOf(392.0, 523.25, 659.25, 783.99, 1046.50, 1318.51), noteDurationMs = 60)

    fun playTap() = playSound(tapBuffer)
    fun playCorrect() = playSound(correctBuffer)
    fun playWrong() = playSound(wrongBuffer)
    fun playMultiplierUp() = playSound(multiplierBuffer)
    fun playPerfect() = playSound(perfectBuffer)
    fun playGameOver() = playSound(gameOverBuffer)
    fun playCountdownTick() = playSound(countdownTickBuffer)
    fun playCountdownGo() = playSound(countdownGoBuffer)
    fun playRevive() = playSound(reviveBuffer)

    private fun playSound(audioData: ShortArray) {
        if (!settingsManager.soundEnabled) return
        scope.launch {
            try {
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(audioData.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(audioData, 0, audioData.size)
                audioTrack.play()

                // Release after playback finished
                val playDurationMs = (audioData.size * 1000L) / sampleRate + 50L
                kotlinx.coroutines.delay(playDurationMs)
                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) {
                // Audio track graceful fallback
            }
        }
    }

    private fun generateToneBuffer(
        frequencies: DoubleArray,
        durationMs: Int,
        attackMs: Int = 5,
        decayMs: Int = durationMs - 5
    ): ShortArray {
        val totalSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(totalSamples)
        val attackSamples = (sampleRate * attackMs) / 1000
        val decaySamples = totalSamples - attackSamples

        for (i in 0 until totalSamples) {
            var sample = 0.0
            for (freq in frequencies) {
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                sample += sin(angle)
            }
            sample /= frequencies.size

            // Envelope (ADSR)
            val envelope = when {
                i < attackSamples -> i.toDouble() / attackSamples
                else -> 1.0 - ((i - attackSamples).toDouble() / decaySamples)
            }.coerceIn(0.0, 1.0)

            buffer[i] = (sample * envelope * Short.MAX_VALUE * 0.75).toInt().toShort()
        }
        return buffer
    }

    private fun generateChimeBuffer(frequencies: DoubleArray, durationMs: Int): ShortArray {
        val noteSamples = (sampleRate * (durationMs / frequencies.size)) / 1000
        val totalSamples = noteSamples * frequencies.size
        val buffer = ShortArray(totalSamples)

        frequencies.forEachIndexed { noteIndex, freq ->
            val startIdx = noteIndex * noteSamples
            for (i in 0 until noteSamples) {
                val globalIdx = startIdx + i
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                val sample = sin(angle) + 0.3 * sin(angle * 2.0)
                val env = 1.0 - (i.toDouble() / noteSamples)
                buffer[globalIdx] = (sample * env * Short.MAX_VALUE * 0.6).toInt().toShort()
            }
        }
        return buffer
    }

    private fun generateArpeggioBuffer(frequencies: DoubleArray, noteDurationMs: Int): ShortArray {
        val noteSamples = (sampleRate * noteDurationMs) / 1000
        val totalSamples = noteSamples * frequencies.size
        val buffer = ShortArray(totalSamples)

        frequencies.forEachIndexed { noteIdx, freq ->
            val startIdx = noteIdx * noteSamples
            for (i in 0 until noteSamples) {
                val globalIdx = startIdx + i
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                val sample = sin(angle) + 0.25 * sin(angle * 2.0)
                val env = 1.0 - (i.toDouble() / noteSamples) * 0.8
                buffer[globalIdx] = (sample * env * Short.MAX_VALUE * 0.65).toInt().toShort()
            }
        }
        return buffer
    }

    private fun generateCelebrationBuffer(): ShortArray {
        val freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98)
        val noteSamples = (sampleRate * 60) / 1000
        val tailSamples = (sampleRate * 200) / 1000
        val totalSamples = noteSamples * freqs.size + tailSamples
        val buffer = ShortArray(totalSamples)

        freqs.forEachIndexed { noteIdx, freq ->
            val startIdx = noteIdx * noteSamples
            for (i in 0 until noteSamples) {
                val globalIdx = startIdx + i
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                val sample = sin(angle) + 0.2 * sin(angle * 2.0)
                val env = 1.0 - (i.toDouble() / noteSamples) * 0.5
                buffer[globalIdx] = (sample * env * Short.MAX_VALUE * 0.7).toInt().toShort()
            }
        }

        // Final sustained high chord
        val finalStart = freqs.size * noteSamples
        val highFreq = 1567.98
        for (i in 0 until tailSamples) {
            val globalIdx = finalStart + i
            val angle = 2.0 * Math.PI * i / (sampleRate / highFreq)
            val sample = sin(angle)
            val env = 1.0 - (i.toDouble() / tailSamples)
            buffer[globalIdx] = (sample * env * Short.MAX_VALUE * 0.7).toInt().toShort()
        }

        return buffer
    }
}
