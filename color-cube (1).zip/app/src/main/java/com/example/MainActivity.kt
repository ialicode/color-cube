package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.game.GamePhase
import com.example.game.GameViewModel
import com.example.ui.components.CountdownOverlay
import com.example.ui.screens.DailyChallengeScreen
import com.example.ui.screens.GameOverScreen
import com.example.ui.screens.GamePlayScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PersonalRecordsScreen
import com.example.ui.screens.RevivePromptScreen
import com.example.ui.screens.ReviveSuccessScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBackground

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                ColorCubeMainApp(
                    activity = this,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun ColorCubeMainApp(
    activity: ComponentActivity,
    viewModel: GameViewModel
) {
    val gameState by viewModel.gameState.collectAsState()
    val dailyStreak by viewModel.dailyStreak.collectAsState()
    val gameStats by viewModel.gameStats.collectAsState()
    val recentHistory by viewModel.recentHistory.collectAsState()
    val todayChallenge by viewModel.todayChallenge.collectAsState()

    // Handle back button logically
    BackHandler(enabled = gameState.phase != GamePhase.HOME) {
        when (gameState.phase) {
            GamePhase.PLAYING, GamePhase.COUNTDOWN -> {
                viewModel.navigateToHome(activity)
            }
            GamePhase.REVIVE_PROMPT, GamePhase.REVIVE_SUCCESS, GamePhase.GAME_OVER, GamePhase.DAILY_RESULTS -> {
                viewModel.navigateToHome(activity)
            }
            GamePhase.RECORDS, GamePhase.SETTINGS -> {
                viewModel.navigateToHome()
            }
            else -> {
                viewModel.navigateToHome()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
    ) {
        AnimatedContent(
            targetState = gameState.phase,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "ScreenTransition"
        ) { phase ->
            when (phase) {
                GamePhase.HOME -> {
                    HomeScreen(
                        dailyStreak = dailyStreak,
                        gameStats = gameStats,
                        isDailyChallengeCompleted = todayChallenge?.completed == true,
                        onPlayClick = { viewModel.startNormalGame() },
                        onDailyChallengeClick = {
                            viewModel.startDailyChallenge()
                        },
                        onRecordsClick = { viewModel.navigateToRecords() },
                        onSettingsClick = { viewModel.navigateToSettings() }
                    )
                }

                GamePhase.COUNTDOWN, GamePhase.PLAYING -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        GamePlayScreen(
                            gameState = gameState,
                            onOptionSelected = { selectedColor ->
                                viewModel.selectAnswer(selectedColor)
                            }
                        )

                        if (phase == GamePhase.COUNTDOWN) {
                            CountdownOverlay(
                                countdownText = gameState.countdownText
                            )
                        }
                    }
                }

                GamePhase.REVIVE_PROMPT -> {
                    RevivePromptScreen(
                        gameState = gameState,
                        onSaveRunClick = {
                            viewModel.requestSaveMyRun(activity)
                        },
                        onEndGameClick = {
                            viewModel.declineRevive()
                        }
                    )
                }

                GamePhase.REVIVE_SUCCESS -> {
                    ReviveSuccessScreen(
                        gameState = gameState,
                        onContinueClick = {
                            viewModel.continueFromReviveSuccess()
                        }
                    )
                }

                GamePhase.GAME_OVER -> {
                    GameOverScreen(
                        gameState = gameState,
                        onPlayAgainClick = {
                            viewModel.playAgain(activity)
                        },
                        onHomeClick = {
                            viewModel.navigateToHome(activity)
                        }
                    )
                }

                GamePhase.DAILY_RESULTS -> {
                    DailyChallengeScreen(
                        dailyChallenge = todayChallenge,
                        onStartChallengeClick = {
                            viewModel.startDailyChallenge()
                        },
                        onBackClick = {
                            viewModel.navigateToHome(activity)
                        }
                    )
                }

                GamePhase.RECORDS -> {
                    PersonalRecordsScreen(
                        gameStats = gameStats,
                        recentHistory = recentHistory,
                        onBackClick = { viewModel.navigateToHome() }
                    )
                }

                GamePhase.SETTINGS -> {
                    SettingsScreen(
                        settingsManager = viewModel.settingsManager,
                        onSoundToggle = { viewModel.toggleSound(it) },
                        onHapticsToggle = { viewModel.toggleHaptics(it) },
                        onNotificationsToggle = { enabled, ctx ->
                            viewModel.toggleNotifications(enabled, ctx)
                        },
                        onTestAdsToggle = { viewModel.toggleTestAds(it) },
                        onResetRecords = { viewModel.resetRecords() },
                        onBackClick = { viewModel.navigateToHome() }
                    )
                }
            }
        }
    }
}
