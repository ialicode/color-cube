package com.example.ads

/**
 * Centralized AdMob Configuration
 *
 * Switch [IS_TEST_MODE] to false before releasing production builds to the Google Play Store.
 */
object AdConfig {
    /**
     * Master AdMob Test Mode Switch:
     * - `true`: Loads Google's official Android Test Ad Unit IDs (never serves live ads, safe for testing/development).
     * - `false`: Loads live Production Ad Unit IDs.
     */
    const val IS_TEST_MODE: Boolean = true

    // ================= PRODUCTION ADMOB IDS =================
    const val ADMOB_APP_ID: String = "ca-app-pub-3497039444769697~9304738393"
    const val PROD_INTERSTITIAL_AD_UNIT_ID: String = "ca-app-pub-3497039444769697/2858216712"
    const val PROD_REWARDED_AD_UNIT_ID: String = "ca-app-pub-3497039444769697/8384362797"

    // ================= OFFICIAL GOOGLE TEST ADMOB IDS =================
    // Standard Google sample test unit IDs for Android
    const val TEST_INTERSTITIAL_AD_UNIT_ID: String = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_AD_UNIT_ID: String = "ca-app-pub-3940256099942544/5224354917"

    /**
     * Returns the active Interstitial Ad Unit ID based on [IS_TEST_MODE] (or optional settings override).
     */
    fun getInterstitialAdUnitId(settingsOverrideTestMode: Boolean? = null): String {
        val useTestMode = if (IS_TEST_MODE) true else (settingsOverrideTestMode ?: false)
        return if (useTestMode) {
            TEST_INTERSTITIAL_AD_UNIT_ID
        } else {
            PROD_INTERSTITIAL_AD_UNIT_ID
        }
    }

    /**
     * Returns the active Rewarded Ad Unit ID based on [IS_TEST_MODE] (or optional settings override).
     */
    fun getRewardedAdUnitId(settingsOverrideTestMode: Boolean? = null): String {
        val useTestMode = if (IS_TEST_MODE) true else (settingsOverrideTestMode ?: false)
        return if (useTestMode) {
            TEST_REWARDED_AD_UNIT_ID
        } else {
            PROD_REWARDED_AD_UNIT_ID
        }
    }
}
