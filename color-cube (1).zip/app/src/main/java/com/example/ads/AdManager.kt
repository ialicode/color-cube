package com.example.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.SettingsManager
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class AdManager(
    private val context: Context,
    private val settingsManager: SettingsManager
) {
    companion object {
        private const val TAG = "ColorCubeAdManager"
        const val INTERSTITIAL_GAME_FREQUENCY = 3

        private fun getErrorExplanation(errorCode: Int): String {
            return when (errorCode) {
                AdRequest.ERROR_CODE_INTERNAL_ERROR -> "ERROR_CODE_INTERNAL_ERROR (0) - An internal error occurred in the SDK/Google servers."
                AdRequest.ERROR_CODE_INVALID_REQUEST -> "ERROR_CODE_INVALID_REQUEST (1) - Invalid ad unit ID, package, or request params."
                AdRequest.ERROR_CODE_NETWORK_ERROR -> "ERROR_CODE_NETWORK_ERROR (2) - Network connection failed or unavailable."
                AdRequest.ERROR_CODE_NO_FILL -> "ERROR_CODE_NO_FILL (3) - Ad inventory unavailable for this request."
                else -> "ERROR_CODE_UNKNOWN ($errorCode)"
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    private var isInterstitialLoading = false
    private var isRewardedLoading = false

    private var interstitialRetryCount = 0
    private var rewardedRetryCount = 0

    val isInterstitialLoaded: Boolean
        get() = interstitialAd != null

    val isRewardedLoaded: Boolean
        get() = rewardedAd != null

    /**
     * Initialize the Google Mobile Ads SDK and start pre-loading initial ads.
     */
    fun initialize() {
        try {
            Log.d(TAG, "Initializing Google Mobile Ads SDK (IS_TEST_MODE=${AdConfig.IS_TEST_MODE}, AppID=${AdConfig.ADMOB_APP_ID})")

            MobileAds.initialize(context) { initStatus ->
                val statusMap = initStatus.adapterStatusMap
                Log.d(TAG, "AdMob SDK Initialized successfully. Adapters count: ${statusMap.size}")
                for ((adapterClass, status) in statusMap) {
                    Log.d(TAG, " -> Adapter: $adapterClass, State: ${status.initializationState}, Latency: ${status.latency}ms")
                }

                // Preload initial test/production ads on main thread
                mainHandler.post {
                    loadInterstitialAd()
                    loadRewardedAd()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fatal error during AdMob SDK initialization: ${e.message}", e)
        }
    }

    private fun getInterstitialAdUnitId(): String {
        return AdConfig.getInterstitialAdUnitId(settingsManager.isTestAds)
    }

    private fun getRewardedAdUnitId(): String {
        return AdConfig.getRewardedAdUnitId(settingsManager.isTestAds)
    }

    /**
     * Request and cache an Interstitial ad.
     */
    fun loadInterstitialAd() {
        if (isInterstitialLoading) {
            Log.d(TAG, "Interstitial ad load already in progress, skipping duplicate request.")
            return
        }
        if (interstitialAd != null) {
            Log.d(TAG, "Interstitial ad is already cached and ready.")
            return
        }

        isInterstitialLoading = true
        val adUnitId = getInterstitialAdUnitId()
        Log.d(TAG, "Requesting Interstitial Ad [Unit ID: $adUnitId, TestMode: ${AdConfig.IS_TEST_MODE}]")

        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    interstitialRetryCount = 0
                    Log.i(TAG, "✅ Interstitial ad loaded successfully [ResponseInfo: ${ad.responseInfo.responseId}]")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.e(
                        TAG,
                        "❌ Interstitial ad failed to load: code=${error.code} | " +
                                "explanation='${getErrorExplanation(error.code)}' | " +
                                "domain='${error.domain}' | " +
                                "message='${error.message}'"
                    )

                    // Auto-retry with backoff up to 30s
                    if (interstitialRetryCount < 4) {
                        interstitialRetryCount++
                        val delayMs = (5000L * interstitialRetryCount).coerceAtMost(30000L)
                        Log.d(TAG, "Scheduling Interstitial ad retry in ${delayMs / 1000}s (attempt #$interstitialRetryCount)")
                        mainHandler.postDelayed({ loadInterstitialAd() }, delayMs)
                    }
                }
            }
        )
    }

    /**
     * Request and cache a Rewarded ad.
     */
    fun loadRewardedAd() {
        if (isRewardedLoading) {
            Log.d(TAG, "Rewarded ad load already in progress, skipping duplicate request.")
            return
        }
        if (rewardedAd != null) {
            Log.d(TAG, "Rewarded ad is already cached and ready.")
            return
        }

        isRewardedLoading = true
        val adUnitId = getRewardedAdUnitId()
        Log.d(TAG, "Requesting Rewarded Ad [Unit ID: $adUnitId, TestMode: ${AdConfig.IS_TEST_MODE}]")

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    rewardedRetryCount = 0
                    Log.i(TAG, "✅ Rewarded ad loaded successfully [ResponseInfo: ${ad.responseInfo.responseId}]")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.e(
                        TAG,
                        "❌ Rewarded ad failed to load: code=${error.code} | " +
                                "explanation='${getErrorExplanation(error.code)}' | " +
                                "domain='${error.domain}' | " +
                                "message='${error.message}'"
                    )

                    // Auto-retry with backoff up to 30s
                    if (rewardedRetryCount < 4) {
                        rewardedRetryCount++
                        val delayMs = (5000L * rewardedRetryCount).coerceAtMost(30000L)
                        Log.d(TAG, "Scheduling Rewarded ad retry in ${delayMs / 1000}s (attempt #$rewardedRetryCount)")
                        mainHandler.postDelayed({ loadRewardedAd() }, delayMs)
                    }
                }
            }
        )
    }

    /**
     * Display the Interstitial ad if the game frequency threshold is met and an ad is ready.
     */
    fun showInterstitialIfReady(activity: Activity, onClosed: () -> Unit) {
        val count = settingsManager.gamesSinceLastInterstitial + 1
        settingsManager.gamesSinceLastInterstitial = count

        Log.d(TAG, "Checking Interstitial frequency: $count/$INTERSTITIAL_GAME_FREQUENCY games (isLoaded=${interstitialAd != null})")

        if (count >= INTERSTITIAL_GAME_FREQUENCY && interstitialAd != null) {
            val ad = interstitialAd
            ad?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(TAG, "📺 Interstitial ad displayed on screen")
                }

                override fun onAdDismissedFullScreenContent() {
                    Log.i(TAG, "Interstitial ad dismissed by user")
                    interstitialAd = null
                    settingsManager.gamesSinceLastInterstitial = 0
                    loadInterstitialAd()
                    onClosed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    Log.e(TAG, "❌ Interstitial ad failed to show: code=${error.code} | domain='${error.domain}' | message='${error.message}'")
                    interstitialAd = null
                    loadInterstitialAd()
                    onClosed()
                }

                override fun onAdClicked() {
                    Log.d(TAG, "Interstitial ad clicked")
                }

                override fun onAdImpression() {
                    Log.d(TAG, "Interstitial ad impression recorded")
                }
            }
            Log.d(TAG, "Presenting Interstitial Ad to player...")
            ad?.show(activity)
        } else {
            // Frequency limit not reached or ad not ready yet
            if (interstitialAd == null) {
                loadInterstitialAd()
            }
            onClosed()
        }
    }

    /**
     * Display the Rewarded ad for SAVE MY RUN.
     */
    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdFailedOrClosed: () -> Unit
    ) {
        val ad = rewardedAd
        Log.d(TAG, "showRewardedAd invoked (isLoaded=${ad != null})")

        if (ad != null) {
            var rewardGiven = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(TAG, "📺 Rewarded ad displayed on screen")
                }

                override fun onAdDismissedFullScreenContent() {
                    Log.i(TAG, "Rewarded ad dismissed. Reward verified: $rewardGiven")
                    rewardedAd = null
                    loadRewardedAd()
                    if (rewardGiven) {
                        onRewardEarned()
                    } else {
                        onAdFailedOrClosed()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    Log.e(TAG, "❌ Rewarded ad failed to show: code=${error.code} | domain='${error.domain}' | message='${error.message}'")
                    rewardedAd = null
                    loadRewardedAd()
                    // Fail-open: if displaying ad fails, gracefully reward player so game isn't broken
                    onRewardEarned()
                }

                override fun onAdClicked() {
                    Log.d(TAG, "Rewarded ad clicked")
                }

                override fun onAdImpression() {
                    Log.d(TAG, "Rewarded ad impression recorded")
                }
            }

            Log.d(TAG, "Presenting Rewarded Ad to player...")
            ad.show(activity) { rewardItem ->
                Log.i(TAG, "🎉 Reward earned by user: amount=${rewardItem.amount}, type=${rewardItem.type}")
                rewardGiven = true
            }
        } else {
            // Ad not loaded or network issue -> fail-open reward granted
            Log.w(TAG, "Rewarded ad was not ready at time of request. Granting fail-safe revive & requesting new ad.")
            loadRewardedAd()
            onRewardEarned()
        }
    }
}

