package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.game.GameColor
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    val size: Float,
    val alpha: Float
)

@Composable
fun Cube3DView(
    gameColor: GameColor,
    size: Dp = 220.dp,
    isPerfectActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val scaleAnim = remember { Animatable(0.7f) }
    val rotationAnim = remember { Animatable(0f) }

    LaunchedEffect(gameColor) {
        scaleAnim.snapTo(0.65f)
        scaleAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "cubeFloat")
    val floatOffsetY by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floatY"
    )

    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    val primary = gameColor.primaryColor
    val top = gameColor.topColor
    val side = gameColor.sideColor

    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scaleAnim.value
                scaleY = scaleAnim.value
                translationY = floatOffsetY
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.toPx() / 2f
            val cy = size.toPx() / 2f
            val r = (size.toPx() / 2f) * 0.58f

            // 1. Ambient Glow Aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primary.copy(alpha = 0.45f * pulseGlow),
                        primary.copy(alpha = 0.15f * pulseGlow),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = r * 1.8f
                ),
                radius = r * 1.8f,
                center = Offset(cx, cy)
            )

            // Isometric 3D Cube Coordinates
            // Isometric projection angles (30 degrees)
            val h = r * 0.866f // cos(30 deg) * r
            val v = r * 0.5f   // sin(30 deg) * r

            val pCenter = Offset(cx, cy)
            val pTop = Offset(cx, cy - r)
            val pTopRight = Offset(cx + h, cy - v)
            val pBottomRight = Offset(cx + h, cy + v)
            val pBottom = Offset(cx, cy + r)
            val pBottomLeft = Offset(cx - h, cy + v)
            val pTopLeft = Offset(cx - h, cy - v)

            // TOP FACE
            val topFace = Path().apply {
                moveTo(pCenter.x, pCenter.y)
                lineTo(pTopRight.x, pTopRight.y)
                lineTo(pTop.x, pTop.y)
                lineTo(pTopLeft.x, pTopLeft.y)
                close()
            }
            drawPath(
                path = topFace,
                brush = Brush.linearGradient(
                    colors = listOf(top, primary),
                    start = pTop,
                    end = pCenter
                )
            )

            // LEFT FACE
            val leftFace = Path().apply {
                moveTo(pCenter.x, pCenter.y)
                lineTo(pTopLeft.x, pTopLeft.y)
                lineTo(pBottomLeft.x, pBottomLeft.y)
                lineTo(pBottom.x, pBottom.y)
                close()
            }
            drawPath(
                path = leftFace,
                brush = Brush.linearGradient(
                    colors = listOf(primary, side),
                    start = pCenter,
                    end = pBottomLeft
                )
            )

            // RIGHT FACE
            val rightFace = Path().apply {
                moveTo(pCenter.x, pCenter.y)
                lineTo(pBottom.x, pBottom.y)
                lineTo(pBottomRight.x, pBottomRight.y)
                lineTo(pTopRight.x, pTopRight.y)
                close()
            }
            drawPath(
                path = rightFace,
                brush = Brush.linearGradient(
                    colors = listOf(side, side.copy(alpha = 0.9f)),
                    start = pCenter,
                    end = pBottomRight
                )
            )

            // Inner Glass Highlight & Bevel Edges
            val strokeColor = Color.White.copy(alpha = 0.35f)
            drawPath(topFace, color = strokeColor, style = Stroke(width = 2.5f))
            drawPath(leftFace, color = strokeColor.copy(alpha = 0.2f), style = Stroke(width = 2.5f))
            drawPath(rightFace, color = strokeColor.copy(alpha = 0.2f), style = Stroke(width = 2.5f))

            // Specular reflection stripe on top face
            drawLine(
                color = Color.White.copy(alpha = 0.5f),
                start = Offset(cx - h * 0.4f, cy - r * 0.4f),
                end = Offset(cx + h * 0.4f, cy - r * 0.4f),
                strokeWidth = 3f
            )

            // Floating celebration particle effects on PERFECT event
            if (isPerfectActive) {
                val rand = Random(42)
                for (i in 0 until 18) {
                    val angle = (i * 20) * (Math.PI / 180.0)
                    val dist = r * (1.1f + (i % 3) * 0.25f)
                    val px = cx + (cos(angle) * dist).toFloat()
                    val py = cy + (sin(angle) * dist).toFloat()
                    drawCircle(
                        color = if (i % 2 == 0) Color.White else primary,
                        radius = 4f + (i % 4),
                        center = Offset(px, py)
                    )
                }
            }
        }
    }
}
