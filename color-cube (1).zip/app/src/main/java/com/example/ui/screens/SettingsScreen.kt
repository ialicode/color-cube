package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.SettingsManager
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonRose
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextSlate100
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500

@Composable
fun SettingsScreen(
    settingsManager: SettingsManager,
    onSoundToggle: (Boolean) -> Unit,
    onHapticsToggle: (Boolean) -> Unit,
    onNotificationsToggle: (Boolean, Context) -> Unit,
    onTestAdsToggle: (Boolean) -> Unit,
    onResetRecords: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var soundEnabled by remember { mutableStateOf(settingsManager.soundEnabled) }
    var hapticsEnabled by remember { mutableStateOf(settingsManager.hapticsEnabled) }
    var notificationsEnabled by remember { mutableStateOf(settingsManager.notificationsEnabled) }
    var isTestAds by remember { mutableStateOf(settingsManager.isTestAds) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("settings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TextSlate100
                    )
                }

                Text(
                    text = "SETTINGS",
                    color = TextSlate100,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Audio & Feedback Card
            Text(
                text = "AUDIO & FEEDBACK",
                color = TextSlate500,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SettingsToggleRow(
                    title = "Sound Effects",
                    subtitle = "Dynamic synthesizers for combos & chimes",
                    icon = Icons.Default.VolumeUp,
                    checked = soundEnabled,
                    onCheckedChange = {
                        soundEnabled = it
                        onSoundToggle(it)
                    },
                    testTag = "sound_toggle"
                )

                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SurfaceCardBorder))

                SettingsToggleRow(
                    title = "Haptic Vibration",
                    subtitle = "Tactile feedback on taps, hits & milestones",
                    icon = Icons.Default.Smartphone,
                    checked = hapticsEnabled,
                    onCheckedChange = {
                        hapticsEnabled = it
                        onHapticsToggle(it)
                    },
                    testTag = "haptics_toggle"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Reminders & Ads Card
            Text(
                text = "REMINDERS & ADS",
                color = TextSlate500,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SettingsToggleRow(
                    title = "Daily Streak Reminders",
                    subtitle = "Notify 6h before day ends to save your streak",
                    icon = Icons.Default.Notifications,
                    checked = notificationsEnabled,
                    onCheckedChange = {
                        notificationsEnabled = it
                        onNotificationsToggle(it, context)
                    },
                    testTag = "notifications_toggle"
                )

                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SurfaceCardBorder))

                SettingsToggleRow(
                    title = "Test Ads Mode",
                    subtitle = "Use official Google test ad units for safety",
                    icon = Icons.Default.Tune,
                    checked = isTestAds,
                    onCheckedChange = {
                        isTestAds = it
                        onTestAdsToggle(it)
                    },
                    testTag = "test_ads_toggle"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Data Management Card
            Text(
                text = "DATA MANAGEMENT",
                color = TextSlate500,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .clickable { showResetDialog = true }
                    .padding(16.dp)
                    .testTag("reset_records_button")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Reset",
                        tint = NeonRose,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Reset All Records",
                            color = NeonRose,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Clear high scores, stats and run history",
                            color = TextSlate500,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Legal & Privacy Card
            Text(
                text = "LEGAL & PRIVACY",
                color = TextSlate500,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .clickable { showPrivacyPolicyDialog = true }
                    .padding(16.dp)
                    .testTag("privacy_policy_button")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Privacy Policy",
                        tint = NeonCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Privacy Policy",
                            color = TextSlate100,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Read our data handling, AdMob & privacy practices",
                            color = TextSlate500,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
        }

        // Privacy Policy Dialog
        if (showPrivacyPolicyDialog) {
            Dialog(
                onDismissRequest = { showPrivacyPolicyDialog = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 16.dp, vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(24.dp))
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Privacy Policy",
                                color = TextSlate100,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                            IconButton(onClick = { showPrivacyPolicyDialog = false }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = TextSlate400
                                )
                            }
                        }

                        Text(
                            text = "Last Updated: August 20, 2026",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .height(420.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = """
This Privacy Policy explains how Color Cube ("we," "our," or "the app") handles information when you use the Color Cube Android application.

Color Cube is a reaction and color-recognition game. We designed the app to minimize the collection of personal information.

1. Information We Collect
Color Cube does not require users to create an account, provide their name, email address, phone number, or other personal information.

The app may store game-related information locally on the user's device, including:
• Scores
• Personal records
• Game streaks
• Daily Challenge results
• Game settings
• Sound preferences
• Haptic preferences
• Notification preferences
• Other information necessary for the game to function

This information is used only to provide the game's features and is stored locally on the device. We do not operate a user account system for Color Cube.

2. Advertising and Google AdMob
Color Cube uses Google AdMob to display advertisements, including interstitial and rewarded advertisements.

Google Mobile Ads SDK may automatically collect and process certain information for purposes including advertising, analytics, fraud prevention, and improving ad performance.

Depending on the applicable configuration and user's device/settings, this may include:
• IP address
• Advertising or device identifiers
• App interactions
• Advertisement interactions
• Diagnostic and performance information
• General location information estimated from IP address

Color Cube does not directly collect this information for its own user database. Advertising-related information may be processed by Google and its advertising services according to Google's applicable policies.

3. Advertising Consent
Where legally required, Color Cube may use Google's consent-management technology (User Messaging Platform) to obtain and manage users' choices regarding personalized advertising and related data processing.

4. Rewarded Advertisements
Color Cube may offer users the option to voluntarily watch a rewarded advertisement in exchange for an additional in-game life. Watching is completely optional.

5. Analytics
Color Cube does not intentionally create a separate personal profile or user account based on information collected through the game.

6. Sharing of Information
Color Cube does not sell users' personal information. We do not maintain a database of users' names, email addresses, phone numbers, or passwords.

7. Data Security
We take reasonable measures to minimize unnecessary collection of personal information. Information stored locally remains on the user's device.

8. Children's Privacy
Color Cube is not designed to knowingly collect personal information from children.

9. Your Choices
You may choose whether to enable notifications, sound, haptic feedback, decline optional rewarded ads, reset device advertising identifiers in Android settings, or uninstall the app to remove all local data.

10. Third-Party Services
Color Cube uses Google AdMob for displaying advertisements.

11. Contact Us
If you have questions about this Privacy Policy, you may contact us at:
info@openwavetech.com
                                """.trimIndent(),
                                color = TextSlate400,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        TextButton(
                            onClick = { showPrivacyPolicyDialog = false },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Close", color = NeonCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Confirmation Dialog
        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                title = {
                    Text(
                        text = "Reset Records?",
                        color = TextSlate100,
                        fontWeight = FontWeight.Black
                    )
                },
                text = {
                    Text(
                        text = "This will permanently erase your high scores, best streaks, and past run history. This action cannot be undone.",
                        color = TextSlate400
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onResetRecords()
                            showResetDialog = false
                        }
                    ) {
                        Text("Reset", color = NeonRose, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text("Cancel", color = TextSlate400)
                    }
                },
                containerColor = SurfaceCard,
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NeonCyan,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = title,
                    color = TextSlate100,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = TextSlate500,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextSlate400,
                uncheckedTrackColor = Color(0xFF1E222D)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
