package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.GameHistoryEntity
import com.example.data.db.GameStatsEntity
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRose
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextSlate100
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500

@Composable
fun PersonalRecordsScreen(
    gameStats: GameStatsEntity?,
    recentHistory: List<GameHistoryEntity>,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats = gameStats ?: GameStatsEntity()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("personal_records_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("records_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TextSlate100
                    )
                }

                Text(
                    text = "PERSONAL RECORDS",
                    color = TextSlate100,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // High Score Hero Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(SurfaceCard)
                            .border(1.dp, NeonAmber.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ALL-TIME HIGH SCORE",
                                    color = TextSlate500,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format("%,d", stats.highScore),
                                    color = NeonAmber,
                                    fontSize = 36.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(NeonAmber.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = "Trophy",
                                    tint = NeonAmber,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }
                }

                // Benchmarks Grid
                item {
                    Text(
                        text = "BENCHMARKS & STATS",
                        color = TextSlate500,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(24.dp))
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatResultItem(
                                label = "LONGEST STREAK",
                                value = "${stats.longestStreak} Answers",
                                accentColor = NeonCyan
                            )
                            StatResultItem(
                                label = "BEST ACCURACY",
                                value = "${String.format("%.1f", stats.bestAccuracy)}%",
                                accentColor = NeonEmerald
                            )
                        }

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SurfaceCardBorder))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatResultItem(
                                label = "FASTEST REACTION",
                                value = if (stats.fastestReactionMs > 0) "${stats.fastestReactionMs} ms" else "-",
                                accentColor = NeonRose
                            )
                            StatResultItem(
                                label = "MAX MULTIPLIER",
                                value = "${stats.highestMultiplier}X",
                                accentColor = NeonIndigo
                            )
                        }

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SurfaceCardBorder))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatResultItem(
                                label = "PERFECT MILESTONES",
                                value = "${stats.perfectMilestones}",
                                accentColor = NeonPurple
                            )
                            StatResultItem(
                                label = "BEST DAILY CHALLENGE",
                                value = String.format("%,d", stats.bestDailyChallengeScore),
                                accentColor = NeonAmber
                            )
                        }

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SurfaceCardBorder))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatResultItem(
                                label = "GAMES PLAYED",
                                value = "${stats.totalGamesPlayed}",
                                accentColor = TextSlate100
                            )
                            StatResultItem(
                                label = "TOTAL CORRECT",
                                value = "${stats.totalCorrectAnswers}",
                                accentColor = NeonCyan
                            )
                        }
                    }
                }

                // Recent History List
                item {
                    Text(
                        text = "RECENT RUNS",
                        color = TextSlate500,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )
                }

                if (recentHistory.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No game history yet. Play a game to record stats!",
                                color = TextSlate500,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    items(recentHistory) { history ->
                        HistoryRowItem(history = history)
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun HistoryRowItem(history: GameHistoryEntity) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (history.mode == "DAILY_CHALLENGE") "DAILY" else "NORMAL",
                        color = if (history.mode == "DAILY_CHALLENGE") NeonAmber else NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "•",
                        color = TextSlate500
                    )
                    Text(
                        text = history.date,
                        color = TextSlate500,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = String.format("%,d pts", history.score),
                    color = TextSlate100,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("%.0f", history.accuracy)}% ACC • STREAK ${history.streak}",
                    color = TextSlate400,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (history.avgReactionMs > 0) {
                    Text(
                        text = "${history.avgReactionMs}ms avg",
                        color = TextSlate500,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
