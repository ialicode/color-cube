package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VibrantDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = ObsidianBackground,
    primaryContainer = SurfaceCard,
    onPrimaryContainer = NeonCyan,
    secondary = NeonAmber,
    onSecondary = ObsidianBackground,
    secondaryContainer = SurfaceCardBorder,
    onSecondaryContainer = NeonAmber,
    tertiary = NeonEmerald,
    onTertiary = Color.White,
    background = ObsidianBackground,
    onBackground = TextSlate100,
    surface = SurfaceDark,
    onSurface = TextSlate100,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSlate400,
    error = NeonRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VibrantDarkColorScheme,
        typography = Typography,
        content = content
    )
}
