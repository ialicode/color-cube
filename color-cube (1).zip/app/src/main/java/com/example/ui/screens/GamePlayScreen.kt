package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.ColorQuestion
import com.example.game.GameColor
import com.example.game.GameMode
import com.example.game.GameSessionState
import com.example.ui.components.Cube3DView
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonRose
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextSlate100
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500

@Composable
fun GamePlayScreen(
    gameState: GameSessionState,
    onOptionSelected: (GameColor) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentQuestion = gameState.currentQuestion

    // Timer animation for current question
    val timerProgress = remember { Animatable(1f) }
    LaunchedEffect(currentQuestion) {
        if (currentQuestion != null) {
            timerProgress.snapTo(1f)
            timerProgress.animateTo(
                targetValue = 0f,
                animationSpec = tween(
                    durationMillis = currentQuestion.timeLimitMs.toInt(),
                    easing = LinearEasing
                )
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("gameplay_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ================= HEADER =================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Score display
                    Column {
                        Text(
                            text = if (gameState.mode == GameMode.DAILY_CHALLENGE) {
                                "DAILY CHALLENGE (${gameState.dailyProgressCurrent}/${gameState.dailyProgressTotal})"
                            } else {
                                "CURRENT SCORE"
                            },
                            color = TextSlate500,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = String.format("%,d", gameState.score),
                                color = TextSlate100,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.testTag("score_display")
                            )

                            // Subtle visual feedback: +1, +2, or +3 based on multiplier
                            AnimatedVisibility(
                                visible = gameState.lastAnswerWasCorrect == true && gameState.lastPointsAwarded > 0,
                                enter = fadeIn(tween(100)) + scaleIn(tween(150)),
                                exit = fadeOut(tween(200))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            when (gameState.lastPointsAwarded) {
                                                3 -> NeonRose.copy(alpha = 0.25f)
                                                2 -> NeonAmber.copy(alpha = 0.25f)
                                                else -> NeonCyan.copy(alpha = 0.25f)
                                            }
                                        )
                                        .border(
                                            0.5.dp,
                                            when (gameState.lastPointsAwarded) {
                                                3 -> NeonRose
                                                2 -> NeonAmber
                                                else -> NeonCyan
                                            },
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "+${gameState.lastPointsAwarded}",
                                        color = when (gameState.lastPointsAwarded) {
                                            3 -> NeonRose
                                            2 -> NeonAmber
                                            else -> NeonCyan
                                        },
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // Lives Display
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.testTag("lives_container")
                    ) {
                        for (i in 1..gameState.maxLives) {
                            val isAlive = i <= gameState.lives
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isAlive) NeonRose.copy(alpha = 0.2f) else SurfaceCard
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isAlive) NeonRose.copy(alpha = 0.4f) else SurfaceCardBorder,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "❤️",
                                    fontSize = 13.sp,
                                    modifier = Modifier.scale(if (isAlive) 1f else 0.8f),
                                    color = if (isAlive) NeonRose else TextSlate500.copy(alpha = 0.2f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ================= PROGRESS BAR & COMBO =================
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Gradient Timer Bar
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E222D))
                            .border(0.5.dp, Color(0xFF2A3040), CircleShape)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(timerProgress.value)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(NeonIndigo, NeonCyan)
                                    )
                                )
                        )
                    }

                    // Combo Multiplier Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (gameState.multiplier > 1) NeonIndigo else Color(0xFF2B3245)
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                .testTag("multiplier_badge")
                        ) {
                            Text(
                                text = "${gameState.multiplier}X",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(
                            text = if (gameState.currentStreak > 0) "STREAK ${gameState.currentStreak}" else "COMBO",
                            color = if (gameState.currentStreak >= 5) NeonAmber else TextSlate400,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // ================= CENTER STROOP CHALLENGE AREA =================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                if (currentQuestion != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // PERFECT! Milestone celebration banner
                        if (gameState.isPerfectEventActive) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .padding(bottom = 8.dp)
                                    .testTag("perfect_banner")
                            ) {
                                Text(
                                    text = "PERFECT!",
                                    color = NeonCyan,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 2.sp
                                )
                                Text(
                                    text = "${gameState.currentStreak} CONSECUTIVE STREAK 🔥",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                            }
                        }

                        // Stroop Word Showcase Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(28.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            SurfaceCard,
                                            SurfaceCard.copy(alpha = 0.6f)
                                        )
                                    )
                                )
                                .border(
                                    width = 1.dp,
                                    color = SurfaceCardBorder,
                                    shape = RoundedCornerShape(28.dp)
                                )
                                .padding(vertical = 40.dp, horizontal = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // THE STROOP COLOR WORD (Displays word text filled with the mismatching textColor)
                            Text(
                                text = currentQuestion.word.displayName.uppercase(),
                                color = currentQuestion.textColor.primaryColor,
                                fontSize = 54.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 3.sp,
                                textAlign = TextAlign.Center,
                                style = TextStyle(
                                    shadow = Shadow(
                                        color = currentQuestion.textColor.primaryColor.copy(alpha = 0.45f),
                                        offset = Offset(0f, 4f),
                                        blurRadius = 20f
                                    )
                                ),
                                modifier = Modifier.testTag("stroop_word_display")
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Clear Stroop Instruction Reminder
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF141720))
                                .border(0.5.dp, Color(0xFF262C3D), RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "TAP THE TEXT COLOR • IGNORE THE WORD",
                                color = TextSlate400,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // ================= 4 ANSWER TILES GRID (RED, BLUE, GREEN, YELLOW) =================
            if (currentQuestion != null) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 28.dp)
                        .testTag("options_grid")
                ) {
                    items(currentQuestion.options) { optionColor ->
                        ColorOptionButton(
                            color = optionColor,
                            isSelected = gameState.selectedOption == optionColor,
                            isCorrect = gameState.lastAnswerWasCorrect,
                            onClick = { onOptionSelected(optionColor) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ColorOptionButton(
    color: GameColor,
    isSelected: Boolean,
    isCorrect: Boolean?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale = if (isPressed) 0.94f else 1f

    val borderColor = when {
        isSelected && isCorrect == true -> Color.White
        isSelected && isCorrect == false -> NeonRose
        else -> Color.White.copy(alpha = 0.25f)
    }

    Box(
        modifier = modifier
            .aspectRatio(1.45f)
            .scale(scale)
            .clip(RoundedCornerShape(24.dp))
            .background(color.primaryColor)
            .border(if (isSelected) 3.dp else 1.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = 8.dp)
            .testTag("color_option_${color.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = color.displayName.uppercase(),
            color = if (color.isLight) Color(0xFF0F172A) else Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        )
    }
}
