package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette - Core Obsidian Dark Backgrounds
val ObsidianBackground = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF141414)
val SurfaceCard = Color(0xFF1E1E24)
val SurfaceCardBorder = Color(0xFF2E2E38)

// Typography & State Colors
val TextSlate100 = Color(0xFFF1F5F9)
val TextSlate400 = Color(0xFF94A3B8)
val TextSlate500 = Color(0xFF64748B)
val TextSlate600 = Color(0xFF475569)

// Vibrant Glow & Accent Palettes
val NeonCyan = Color(0xFF22D3EE)
val NeonIndigo = Color(0xFF6366F1)
val NeonRose = Color(0xFFF43F5E)
val NeonAmber = Color(0xFFFBBF24)
val NeonEmerald = Color(0xFF10B981)
val NeonPurple = Color(0xFFA855F7)
val NeonOrange = Color(0xFFFB923C)
val NeonPink = Color(0xFFF472B6)

// Game Color Choices for Cubes & Option Buttons
val GameCrimson = Color(0xFFF43F5E)
val GameAmber = Color(0xFFFBBF24)
val GameCyan = Color(0xFF22D3EE)
val GameIndigo = Color(0xFF6366F1)
val GameEmerald = Color(0xFF10B981)
val GamePurple = Color(0xFFA855F7)
val GameCoral = Color(0xFFFF6B6B)
val GameLime = Color(0xFF84CC16)
