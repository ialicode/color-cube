package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameSessionState
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonRose
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextSlate100
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500

@Composable
fun GameOverScreen(
    gameState: GameSessionState,
    onPlayAgainClick: () -> Unit,
    onHomeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("game_over_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // New High Score Banner
                if (gameState.isNewHighScore) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(NeonAmber.copy(alpha = 0.2f), NeonRose.copy(alpha = 0.2f))
                                )
                            )
                            .border(1.dp, NeonAmber, RoundedCornerShape(20.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("new_high_score_badge")
                    ) {
                        Text(
                            text = "👑 NEW PERSONAL RECORD!",
                            color = NeonAmber,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Text(
                    text = "GAME OVER",
                    color = TextSlate100,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    modifier = Modifier.testTag("game_over_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "FINAL SCORE",
                    color = TextSlate500,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )

                Text(
                    text = String.format("%,d", gameState.score),
                    color = NeonCyan,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("final_score_text")
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Detailed Game Statistics Grid Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(24.dp))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatResultItem(
                            label = "ACCURACY",
                            value = "${String.format("%.1f", gameState.accuracyPercentage)}%",
                            accentColor = NeonEmerald
                        )
                        StatResultItem(
                            label = "BEST STREAK",
                            value = "${gameState.bestStreakInRun}",
                            accentColor = NeonAmber
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(SurfaceCardBorder)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatResultItem(
                            label = "AVG REACTION",
                            value = if (gameState.averageReactionTimeMs > 0) "${gameState.averageReactionTimeMs} ms" else "-",
                            accentColor = TextSlate100
                        )
                        StatResultItem(
                            label = "FASTEST REACTION",
                            value = if (gameState.fastestReactionTimeMs > 0) "${gameState.fastestReactionTimeMs} ms" else "-",
                            accentColor = NeonCyan
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(SurfaceCardBorder)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatResultItem(
                            label = "MAX MULTIPLIER",
                            value = "${gameState.multiplier}X",
                            accentColor = NeonIndigo
                        )
                        StatResultItem(
                            label = "PERFECT MILESTONES",
                            value = "${gameState.perfectMilestonesInRun}",
                            accentColor = NeonRose
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Compact Share Score Button
                val context = LocalContext.current
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCard)
                        .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            try {
                                val shareText = """
                                    🎨 Color Cube
                                    Score: ${gameState.score}
                                    Best Streak: ${gameState.bestStreakInRun}
                                    Accuracy: ${String.format("%.1f", gameState.accuracyPercentage)}%

                                    Can you beat my score in Color Cube? 🔥
                                """.trimIndent()

                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Color Cube Score")
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                }
                                val chooserIntent = Intent.createChooser(sendIntent, "Share Color Cube Score")
                                context.startActivity(chooserIntent)
                            } catch (e: Exception) {
                                // Handled gracefully if no share app is available
                            }
                        }
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                        .testTag("share_score_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Score",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "↗ SHARE SCORE",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons: PLAY AGAIN & HOME
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                HomeActionButton(
                    text = "PLAY AGAIN",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Replay,
                            contentDescription = "Play Again",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    gradient = Brush.horizontalGradient(listOf(NeonCyan, NeonIndigo)),
                    textColor = Color.Black,
                    isPrimary = true,
                    onClick = onPlayAgainClick,
                    testTag = "play_again_button"
                )

                HomeActionButton(
                    text = "HOME",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home",
                            tint = TextSlate100,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    bgColor = SurfaceCard,
                    borderColor = SurfaceCardBorder,
                    textColor = TextSlate100,
                    onClick = onHomeClick,
                    testTag = "home_button"
                )
            }
        }
    }
}

@Composable
fun StatResultItem(
    label: String,
    value: String,
    accentColor: Color
) {
    Column {
        Text(
            text = label,
            color = TextSlate500,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = accentColor,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black
        )
    }
}
