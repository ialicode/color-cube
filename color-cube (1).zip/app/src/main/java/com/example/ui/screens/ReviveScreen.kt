package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameSessionState
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonRose
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextSlate100
import com.example.ui.theme.TextSlate400
import com.example.ui.theme.TextSlate500

@Composable
fun RevivePromptScreen(
    gameState: GameSessionState,
    onSaveRunClick: () -> Unit,
    onEndGameClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("revive_prompt_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Heartbroken badge
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(NeonRose.copy(alpha = 0.15f))
                    .border(1.5.dp, NeonRose.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "💔",
                    fontSize = 36.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "OUT OF LIVES",
                color = TextSlate500,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "🔥 SAVE YOUR RUN?",
                color = TextSlate100,
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Watch a short ad to get 1 extra life and keep your score and streak alive!",
                color = TextSlate400,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Preserved stats preview
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(vertical = 16.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("CURRENT SCORE", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = String.format("%,d", gameState.score),
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STREAK", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${gameState.bestStreakInRun}",
                        color = NeonAmber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MULTIPLIER", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${gameState.multiplier}X",
                        color = NeonIndigo,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Action Buttons
            HomeActionButton(
                text = "SAVE MY RUN",
                icon = { Text("🔥", fontSize = 18.sp) },
                gradient = Brush.horizontalGradient(listOf(NeonRose, NeonAmber)),
                textColor = Color.White,
                isPrimary = true,
                onClick = onSaveRunClick,
                testTag = "save_my_run_button"
            )

            Spacer(modifier = Modifier.height(14.dp))

            HomeActionButton(
                text = "END GAME",
                icon = { Text("✕", color = TextSlate400, fontWeight = FontWeight.Bold) },
                bgColor = Color.Transparent,
                borderColor = SurfaceCardBorder,
                textColor = TextSlate400,
                onClick = onEndGameClick,
                testTag = "end_game_button"
            )
        }
    }
}

@Composable
fun ReviveSuccessScreen(
    gameState: GameSessionState,
    onContinueClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .statusBarsPadding()
            .testTag("revive_success_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(NeonEmerald.copy(alpha = 0.2f))
                    .border(2.dp, NeonEmerald, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "❤️",
                    fontSize = 42.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "🔥 RUN SAVED!",
                color = NeonEmerald,
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "+1 LIFE RESTORED",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(30.dp))

            // Preserved stats display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(vertical = 18.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SCORE", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = String.format("%,d", gameState.score),
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STREAK", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${gameState.bestStreakInRun}",
                        color = NeonAmber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MULTIPLIER", color = TextSlate500, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${gameState.multiplier}X",
                        color = NeonIndigo,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            HomeActionButton(
                text = "CONTINUE",
                icon = { Text("⚡", fontSize = 18.sp) },
                gradient = Brush.horizontalGradient(listOf(NeonCyan, NeonIndigo)),
                textColor = Color.Black,
                isPrimary = true,
                onClick = onContinueClick,
                testTag = "continue_revive_button"
            )
        }
    }
}
