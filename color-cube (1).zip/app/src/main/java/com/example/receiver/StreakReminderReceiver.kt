package com.example.receiver

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.SettingsManager
import com.example.data.db.ColorCubeDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import kotlin.random.Random

class StreakReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_STREAK_REMINDER = "com.example.ACTION_STREAK_REMINDER"
        const val CHANNEL_ID = "color_cube_streak_reminders"
        const val NOTIFICATION_ID = 1001

        private val REMINDER_MESSAGES = listOf(
            "🔥 Your Color Cube streak is waiting for you!",
            "Don't let your streak disappear today!",
            "Your streak needs you! 🎮",
            "One quick game can save your streak!",
            "Your Color Cube streak is about to expire!",
            "Keep the fire burning! Play today's Color Cube challenge! 🔥",
            "A 2-minute game keeps your record alive! ⏱️",
            "Your daily streak is counting on you! 🎯",
            "Can you beat your best reaction time today? ⚡",
            "Don't break the chain! Tap into Color Cube now! 🟧",
            "Step up your concentration! Save your streak today! 🚀",
            "A few quick taps and your streak is secure! 🏆"
        )

        fun scheduleStreakReminder(context: Context) {
            val settings = SettingsManager(context)
            if (!settings.notificationsEnabled) {
                cancelStreakReminder(context)
                return
            }

            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, StreakReminderReceiver::class.java).apply {
                action = ACTION_STREAK_REMINDER
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Set alarm for 6 hours before day ends: 18:00 (6:00 PM)
            val calendar = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, 18)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis,
                        pendingIntent
                    )
                }
            } catch (e: SecurityException) {
                // Exact alarm permission fallback
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        }

        fun cancelStreakReminder(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, StreakReminderReceiver::class.java).apply {
                action = ACTION_STREAK_REMINDER
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
            }
        }

        fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val name = "Daily Streak Reminders"
                val descriptionText = "Notifications to remind you to keep your Color Cube daily streak alive."
                val importance = NotificationManager.IMPORTANCE_DEFAULT
                val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                    description = descriptionText
                }
                val notificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannel(channel)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            scheduleStreakReminder(context)
            return
        }

        val settings = SettingsManager(context)
        if (!settings.notificationsEnabled) return

        CoroutineScope(Dispatchers.IO).launch {
            val db = ColorCubeDatabase.getDatabase(context)
            val streak = db.gameDao().getDailyStreakDirect()
            val todayStr = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)

            // Only notify if player has an active streak and has not yet played today
            val hasPlayedToday = streak?.lastPlayedDate == todayStr
            if (!hasPlayedToday) {
                val currentStreak = streak?.currentStreak ?: 0
                showNotification(context, currentStreak)
            }

            // Schedule for tomorrow
            scheduleStreakReminder(context)
        }
    }

    private fun showNotification(context: Context, currentStreak: Int) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        createNotificationChannel(context)

        val message = REMINDER_MESSAGES[Random.nextInt(REMINDER_MESSAGES.size)]
        val title = if (currentStreak > 0) {
            "Keep your $currentStreak Day Streak alive! 🔥"
        } else {
            "Color Cube Challenge Ready! 🎮"
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }
}
