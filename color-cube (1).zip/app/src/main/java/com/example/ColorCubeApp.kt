package com.example

import android.app.Application
import com.example.ads.AdManager
import com.example.audio.HapticManager
import com.example.audio.SoundManager
import com.example.data.GameRepository
import com.example.data.SettingsManager
import com.example.data.db.ColorCubeDatabase
import com.example.receiver.StreakReminderReceiver

class ColorCubeApp : Application() {

    lateinit var database: ColorCubeDatabase
        private set
    lateinit var repository: GameRepository
        private set
    lateinit var settingsManager: SettingsManager
        private set
    lateinit var soundManager: SoundManager
        private set
    lateinit var hapticManager: HapticManager
        private set
    lateinit var adManager: AdManager
        private set

    override fun onCreate() {
        super.onCreate()

        database = ColorCubeDatabase.getDatabase(this)
        repository = GameRepository(database.gameDao())
        settingsManager = SettingsManager(this)
        soundManager = SoundManager(this, settingsManager)
        hapticManager = HapticManager(this, settingsManager)
        adManager = AdManager(this, settingsManager)

        // Initialize AdMob
        adManager.initialize()

        // Setup notification channel and daily reminder
        StreakReminderReceiver.createNotificationChannel(this)
        StreakReminderReceiver.scheduleStreakReminder(this)
    }
}
