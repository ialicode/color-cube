# Privacy Policy for Color Cube

**Last Updated: August 20, 2026**

This Privacy Policy explains how **Color Cube** ("we," "our," or "the app") handles information when you use the Color Cube Android application.

Color Cube is a reaction and color-recognition game. We designed the app to minimize the collection of personal information.

## 1. Information We Collect

### Information Stored Locally

Color Cube does not require users to create an account, provide their name, email address, phone number, or other personal information.

The app may store game-related information locally on the user's device, including:

* Scores
* Personal records
* Game streaks
* Daily Challenge results
* Game settings
* Sound preferences
* Haptic preferences
* Notification preferences
* Other information necessary for the game to function

This information is used only to provide the game's features and is stored locally on the device unless otherwise described in this Privacy Policy.

We do not operate a user account system for Color Cube.

## 2. Advertising and Google AdMob

Color Cube uses **Google AdMob** to display advertisements, including interstitial and rewarded advertisements.

Google Mobile Ads SDK may automatically collect and process certain information for purposes including advertising, analytics, fraud prevention, and improving ad performance.

Depending on the applicable configuration and user's device/settings, this may include information such as:

* IP address
* Advertising or device identifiers
* App interactions
* Advertisement interactions
* Diagnostic information
* Performance information
* General location information that may be estimated from an IP address

Google states that its Mobile Ads SDK may collect and share certain information automatically for advertising, analytics, and fraud-prevention purposes.

Color Cube does not directly collect this information for its own user database. Advertising-related information may be processed by Google and its advertising services according to Google's applicable policies.

For more information about Google's privacy practices, please review Google's Privacy Policy.

## 3. Advertising Consent

Where legally required, Color Cube may use Google's consent-management technology to obtain and manage users' choices regarding personalized advertising and related data processing.

The availability and content of consent choices may depend on the user's location and applicable laws.

Google's User Messaging Platform provides consent-management functionality for applicable advertising requirements.

## 4. Rewarded Advertisements

Color Cube may offer users the option to voluntarily watch a rewarded advertisement in exchange for an additional in-game life.

Watching a rewarded advertisement is optional.

The rewarded advertisement is provided through Google AdMob.

Color Cube does not require users to watch advertisements in order to play the core game.

## 5. Analytics

Color Cube does not intentionally create a separate personal profile or user account based on information collected through the game.

If advertising or other third-party SDK functionality processes technical or interaction information, that processing is governed by the applicable third-party service's policies and configurations.

## 6. Sharing of Information

Color Cube does not sell users' personal information.

Color Cube does not maintain a database of users' names, email addresses, phone numbers, passwords, or other account information.

Information may nevertheless be processed or shared by third-party service providers when necessary to provide services used by the application, such as advertising.

In particular, Google AdMob may process information as described above.

## 7. Data Security

We take reasonable measures to minimize unnecessary collection of personal information.

Information stored locally by Color Cube remains on the user's device unless a feature or third-party service causes information to be transmitted.

Information processed by Google services is handled according to Google's security and privacy practices.

Google states that data collected by the Google Mobile Ads SDK is encrypted in transit.

## 8. Children's Privacy

Color Cube is not designed to knowingly collect personal information from children.

The application does not require users to create accounts or submit personal information.

Because Color Cube uses third-party advertising services, advertising and consent settings may vary depending on the user's age, location, and applicable legal requirements.

Parents and guardians should review the applicable Google Play and Google advertising policies when determining whether the app is appropriate for a child.

## 9. Your Choices

You may:

* Choose whether to enable notifications.
* Choose whether to enable sound.
* Choose whether to enable haptic feedback.
* Decline optional rewarded advertisements.
* Manage certain advertising and privacy choices through available Google/Android controls.
* Uninstall the application to remove locally stored Color Cube game data from the device.

Advertising identifiers may also be reset or controlled through Android device settings, subject to the device and operating system version.

## 10. Third-Party Services

Color Cube uses third-party services, including:

**Google AdMob** — for displaying advertisements.

These services may process information according to their own privacy policies and applicable terms.

Users should review Google's current privacy documentation for information about how Google handles information through its advertising services.

## 11. Changes to This Privacy Policy

We may update this Privacy Policy from time to time to reflect changes to the application, advertising services, legal requirements, or our privacy practices.

When changes are made, the "Last Updated" date at the beginning of this policy will be updated.

## 12. Contact Us

If you have questions about this Privacy Policy or Color Cube's privacy practices, you may contact us at:

**Email:** info@openwavetech.com

## 13. Summary

In simple terms:

* Color Cube does not require an account.
* We do not ask users for their name, email, phone number, or password.
* Game progress and settings are primarily stored locally on the device.
* Color Cube uses Google AdMob for advertising.
* AdMob may process certain device, advertising, diagnostic, IP-address, and interaction information.
* Rewarded advertisements are optional.
* We do not sell users' personal information.
* Privacy and advertising choices may vary depending on the user's location and applicable laws.

**By using Color Cube, you acknowledge this Privacy Policy.**
